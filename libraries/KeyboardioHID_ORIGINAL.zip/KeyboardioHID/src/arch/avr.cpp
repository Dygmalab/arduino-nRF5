#include "Arduino.h"

#ifdef ARDUINO_ARCH_AVR

void USB_PackMessages(bool pack) {
}

#endif
